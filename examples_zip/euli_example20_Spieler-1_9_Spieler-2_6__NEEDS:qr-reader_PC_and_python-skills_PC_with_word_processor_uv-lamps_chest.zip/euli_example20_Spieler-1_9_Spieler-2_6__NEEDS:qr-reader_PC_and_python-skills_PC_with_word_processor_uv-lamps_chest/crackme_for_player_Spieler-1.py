#!/usr/bin/env python3

# # Dieses kleine Programm kennt das Geheimnis, das Du suchst, wird es Dir aber erst in 9582790 Billionen Jahren verraten, harhar :) Wenn Du nicht so viel Zeit hast, musst Du einen anderen Weg suchen ...
# Python3!

import base64
import time

exec('print("exec ist ein interessanter Python Befehl")')
time.sleep(1)
print()

command = 'print("exec ist ein wirklich interessanter Python Befehl")'
print('command: ' + command)
exec(command)
time.sleep(1)
print()

command1 = 'print("Dieser Befehl ist in zwei vari'
command2 = 'ablen und wird trotzdem ausgeführt")'
print(command1 + ' --------------- ' + command2)
exec(command1 + command2)
time.sleep(1)
print()

secret_command ='''
CnByaW50KCdIdWgsIHdvaGVyIGtvbW10IGRlbm4gZGllc2VyIENvZGU/JywgZmx1c2g9VHJ1ZSkK
dGltZS5zbGVlcCgxKQpwcmludCgnSWNoIHdlcmRlIERpciBkYXMgR2VoZWltbmlzIGluIDgwOTMy
IEphaHJlbiB2ZXJyYXRlbiEnLCBmbHVzaD1UcnVlKQp0aW1lLnNsZWVwKDk4ODk4OTc4OSkKcHJp
bnQgKCdEYW5rZSBmw7xyIGRhcyBXYXJ0ZW4sIGhpZXIgaXN0IERlaW4gR2VoZWltbmlzOiA6ICcg
KyBiYXNlNjQuYjY0ZGVjb2RlKCdVM1J5Wlc1bklHZGxhR1ZwYlNFZ1JHbGxJRzdEcEdOb2MzUmxJ
RWRsYUdWcGJTMUNiM1J6WTJoaFpuUWdhWE4wSUdsdUlFUmxhVzVsYlNCVFkyaDFiSEpoYm5wbGJp
Qm5kWFFnZG1WeVltOXlaMlZ1SVE9PScpLmRlY29kZSgndXRmOCcpKQo=

'''

sec_cmd_dec = base64.b64decode(secret_command).decode('utf-8')
# ???
exec(sec_cmd_dec)

