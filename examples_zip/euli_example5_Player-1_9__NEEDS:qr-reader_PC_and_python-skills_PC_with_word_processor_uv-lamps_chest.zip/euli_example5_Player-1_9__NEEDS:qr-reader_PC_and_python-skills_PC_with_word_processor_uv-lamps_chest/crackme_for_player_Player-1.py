#!/usr/bin/env python3

# This little script knows the secret you are looking for, but will only tell it in 890601 billion years, harhar :) If you don't have this much time, find a quicker way ...
# Python3!

import base64
import time

exec('print("exec is an interessting python command")')
time.sleep(1)
print()

command = 'print("exec is a really interessting python command")'
print('command: ' + command)
exec(command)
time.sleep(1)
print()

command1 = 'print("This command is in two vari'
command2 = 'ables and soon it will be executed")'
print(command1 + ' --------------- ' + command2)
exec(command1 + command2)
time.sleep(1)
print()

secret_command ='''
CnByaW50KCdIdWgsIHdoZXJlIGRvZXMgdGhpcyBjb2RlIGNvbWUgZnJvbT8nLCBmbHVzaD1UcnVl
KQp0aW1lLnNsZWVwKDEpCnByaW50KCdJIHdpbCB0ZWxsIHlvdSB0aGUgc2VjcmV0IGluIDg5MDYw
MSBiaWxsaW9uIHllYXJzIScsIGZsdXNoPVRydWUpCnRpbWUuc2xlZXAoOTg4OTg5Nzg5KQpwcmlu
dCAoJ1RoYW5rcyBmb3Igd2FpdGluZywgaGVyZSBpcyB5b3VyIHNlY3JldDogOiAnICsgYmFzZTY0
LmI2NGRlY29kZSgnVkc5d0lITmxZM0psZENFZ1ZHaGxJRzVsZUhRZ2MyVmpjbVYwSUcxbGMzTmha
MlVnYVhNZ2FHbGtaR1Z1SUhWdVpHVnlJSGx2ZFhJZ1kyaGhhWElnWVhRZ2RHaGxJR1JwYm1sdVp5
QjBZV0pzWlE9PScpLmRlY29kZSgndXRmOCcpKQo=

'''

sec_cmd_dec = base64.b64decode(secret_command).decode('utf-8')
# ???
exec(sec_cmd_dec)

