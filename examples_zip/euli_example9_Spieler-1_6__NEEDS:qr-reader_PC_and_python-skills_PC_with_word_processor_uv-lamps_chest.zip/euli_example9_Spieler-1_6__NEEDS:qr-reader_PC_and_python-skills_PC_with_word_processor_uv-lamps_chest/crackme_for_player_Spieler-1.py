#!/usr/bin/env python3

# Python3!
# Dieses kleine Programm kennt das Geheimnis, das Du suchst, wird es Dir aber auf gar keinstem Fall überhaupt nicht verraten. Außer die zwingst es dazu ;)

import base64
import hashlib
import time

password=input('Wie lautet das Passwort? ')

hashitem=hashlib.new('sha256')
hashitem.update(password.encode('utf8'))
hexdigest_passwort=hashitem.hexdigest

if hexdigest_passwort == '9f86d081884c7d659a2feaa0c55ad015a3bf4fb12b0b822cd15d6c15b00f0a08' and password[:4:] == 'F' and hexdigest_passwort[1:2:] == 'XR' and False:
    print('Das Geheimnis ist: ')
    secret1 = 'U3Ry'
    secret3 = 'IGdlaGVpbSEgV2VubiBEdSBub2NoIGVpbiBHZWhlaW1uaXMgc3VjaHN0LCBlcyBpc3QgdW50ZXIgRXVyZW4gZ3Jvw59lbiBUZWxsZXJuIHZlcmJvcmdlbiE='
    secret2 = 'ZW5n'
    secret = secret1 + secret2 + secret3
    print (base64.b64decode(secret).decode('utf-8'))

else:
    print('Falsches Passwort!')

