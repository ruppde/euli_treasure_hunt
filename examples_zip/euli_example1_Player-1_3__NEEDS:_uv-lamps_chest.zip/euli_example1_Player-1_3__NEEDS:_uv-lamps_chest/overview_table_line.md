[zip](./examples_zip/euli_example1_Player-1_3__NEEDS:_uv-lamps_chest.zip) | Player-1 (3) | UV marker + UV pocket lamp(s), treasure chest with combination lock | en
