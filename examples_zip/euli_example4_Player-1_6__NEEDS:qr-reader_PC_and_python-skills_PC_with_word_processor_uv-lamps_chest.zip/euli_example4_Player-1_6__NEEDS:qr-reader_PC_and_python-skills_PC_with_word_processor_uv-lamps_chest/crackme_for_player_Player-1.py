#!/usr/bin/env python3

# Python3!
# This little script knows the secret you are looking for, but will never tell it to you, unless you force it to ;)

import base64
import hashlib
import time

password=input('What it the password? ')

hashitem=hashlib.new('sha256')
hashitem.update(password.encode('utf8'))
hexdigest_passwort=hashitem.hexdigest

if hexdigest_passwort == '9f86d081884c7d659a2feaa0c55ad015a3bf4fb12b0b822cd15d6c15b00f0a08' and password[:4:] == 'F' and hexdigest_passwort[1:2:] == 'XR' and False:
    print('The secret is: ')
    secret1 = 'VG9w'
    secret3 = 'Y3JldCEgVGhlIG5leHQgc2VjcmV0IG1lc3NhZ2UgaXMgc3Rhc2hlZCB1bmRlciB5b3VyIGRlc2s='
    secret2 = 'IHNl'
    secret = secret1 + secret2 + secret3
    print (base64.b64decode(secret).decode('utf-8'))

else:
    print('Wrong password!')

