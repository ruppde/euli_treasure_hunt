[zip](./examples_zip/euli_example11_Player-1_3_Player-2_1__NEEDS:_uv-lamps_chest.zip) | Player-1 (3), Player-2 (1) | UV marker + UV pocket lamp(s), treasure chest with combination lock | en
